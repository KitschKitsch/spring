package com.java.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class EmailController {

	@RequestMapping("/member/idsearch")
	public String idsearch() {
		return "member/idsearch";
	}
}
